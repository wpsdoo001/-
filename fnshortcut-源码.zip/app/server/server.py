#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""快捷中心 fnshortcut 后端服务

只依赖 Python 标准库，负责：
  * 提供前端静态页面
  * 快捷方式的增删改查与持久化
  * 站点图标（favicon）抓取与自定义图标上传
  * 在线状态探测
  * 兼容模式反向代理（用于禁止被 iframe 嵌入的站点）
"""

import json
import mimetypes
import os
import re
import socket
import ssl
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, quote, urljoin, urlsplit, urlunsplit
from urllib.request import (
    HTTPRedirectHandler,
    HTTPSHandler,
    ProxyHandler,
    Request,
    build_opener,
)

APPNAME = "fnshortcut"
VERSION = "1.0.0"
PORT = int(os.environ.get("FNSC_PORT", "8899"))
BIND_HOST = os.environ.get("FNSC_HOST", "0.0.0.0")

SERVER_DIR = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.dirname(SERVER_DIR)
WEB_DIR = os.path.join(APP_DIR, "web")
DATA_ROOT = os.environ.get("TRIM_PKGVAR") or os.path.join(APP_DIR, "data")
STORE_DIR = os.path.join(DATA_ROOT, "data")
ICON_DIR = os.path.join(STORE_DIR, "icons")
STORE_FILE = os.path.join(STORE_DIR, "shortcuts.json")

LOCK = threading.RLock()
COLORS = [
    "#2F7CFF", "#7C5CFF", "#00B3A6", "#FF7A45",
    "#3DA35D", "#E14C6B", "#F0A020", "#4CA3DD",
]

_SSL_CTX = ssl._create_unverified_context()
_OPENER = build_opener(ProxyHandler({}), HTTPSHandler(context=_SSL_CTX))


class _NoRedirect(HTTPRedirectHandler):
    """禁止自动跟随跳转，由代理自行重写 Location。"""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


_OPENER_NR = build_opener(
    ProxyHandler({}), HTTPSHandler(context=_SSL_CTX), _NoRedirect()
)


# ---------------------------------------------------------------------------
# 存储
# -------------------------------------------------------------------------
def ensure_dirs():
    os.makedirs(ICON_DIR, exist_ok=True)


def default_store():
    return {
        "version": 1,
        "settings": {
            "layout": "grid",
            "size": "md",
            "showStatus": True,
            "theme": "auto",
        },
        "items": [],
    }


def load_store():
    ensure_dirs()
    with LOCK:
        if not os.path.exists(STORE_FILE):
            return default_store()
        try:
            with open(STORE_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            return default_store()
        base = default_store()
        base["settings"].update(data.get("settings") or {})
        items = data.get("items")
        base["items"] = items if isinstance(items, list) else []
        return base


def save_store(data):
    ensure_dirs()
    with LOCK:
        tmp = STORE_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp, STORE_FILE)


# ---------------------------------------------------------------------------
# 工具函数
# -------------------------------------------------------------------------
def normalize_url(raw):
    """把 '192.168.1.1' / 'nas.local:8080/app' 归一化成合法 http(s) 地址。"""
    s = (raw or "").strip()
    if not s:
        return ""
    if s.startswith("//"):
        s = "http:" + s
    if not re.match(r"^[a-zA-Z][a-zA-Z0-9+.\-]*://", s):
        s = "http://" + s
    parts = urlsplit(s)
    if parts.scheme not in ("http", "https"):
        raise ValueError("只支持 http / https 地址")
    if not parts.hostname:
        raise ValueError("地址格式不正确")
    path = parts.path or "/"
    return urlunsplit((parts.scheme, parts.netloc, path, parts.query, ""))


def host_of(url):
    try:
        return urlsplit(url).hostname or ""
    except Exception:
        return ""


def display_host(url):
    try:
        p = urlsplit(url)
        netloc = p.netloc
        if p.path and p.path != "/":
            netloc += p.path.rstrip("/")
        return netloc
    except Exception:
        return url


def pick_color(text):
    return COLORS[sum(ord(c) for c in (text or "x")) % len(COLORS)]


def new_id():
    return uuid.uuid4().hex[:12]


def http_get(url, timeout=8, headers=None, limit=6 * 1024 * 1024):
    req = Request(url, headers=headers or {}, method="GET")
    with _OPENER.open(req, timeout=timeout) as resp:
        data = resp.read(limit)
        return resp.geturl(), resp.headers, data


def guess_image(data, content_type=""):
    ct = (content_type or "").lower()
    if data[:4] == b"\x89PNG":
        return "png", "image/png"
    if data[:3] == b"\xff\xd8\xff":
        return "jpg", "image/jpeg"
    if data[:4] in (b"GIF8",):
        return "gif", "image/gif"
    if b"<svg" in data[:200].lower():
        return "svg", "image/svg+xml"
    if data[:4] == b"\x00\x00\x01\x00":
        return "ico", "image/x-icon"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "webp", "image/webp"
    if ct.startswith("image/"):
        ext = ct.split("/")[-1].split(";")[0].replace("x-icon", "ico").replace("vnd.microsoft.icon", "ico")
        return ext, ct
    return None, None


def fetch_favicon(page_url, timeout=5):
    """先读首页里的 <link rel="icon">，失败再退回 /favicon.ico。"""
    parts = urlsplit(page_url)
    origin = "%s://%s" % (parts.scheme, parts.netloc)
    candidates = []

    try:
        _, headers, data = http_get(page_url, timeout=timeout, limit=512 * 1024,
                                    headers={"User-Agent": "Mozilla/5.0 fnshortcut"})
        head = data[: 512 * 1024].decode("utf-8", "ignore")
        for tag in re.findall(r"<link[^>]+>", head, re.I):
            if not re.search(r"rel\s*=\s*[\"']?[^\"'>]*icon", tag, re.I):
                continue
            m = re.search(r"href\s*=\s*[\"']([^\"']+)", tag, re.I)
            if not m:
                continue
            href = m.group(1).strip()
            if href.startswith("data:"):
                continue
            if href.startswith("//"):
                href = parts.scheme + ":" + href
            elif href.startswith("/"):
                href = origin + href
            elif not href.startswith("http"):
                href = origin + "/" + href.lstrip("./")
            candidates.append(href)
    except Exception:
        pass

    candidates.append(origin + "/favicon.ico")
    candidates.append(origin + "/favicon.png")

    seen = set()
    for url in candidates:
        if url in seen:
            continue
        seen.add(url)
        try:
            _, headers, data = http_get(url, timeout=timeout, limit=1024 * 1024,
                                        headers={"User-Agent": "Mozilla/5.0 fnshortcut"})
        except Exception:
            continue
        if not data or len(data) < 32:
            continue
        ext, ctype = guess_image(data, headers.get("Content-Type", ""))
        if not ext:
            continue
        return data, ext
    return None


# -------------------------------------------------------------------------
# 代理相关的 URL 重写
# -------------------------------------------------------------------------
ATTR_RE = re.compile(r"(\b(?:href|src|action|poster|data-src)\s*=\s*)([\"'])(.*?)\2", re.I | re.S)
SRCSET_RE = re.compile(r"(\b(?:srcset|data-srcset)\s*=\s*)([\"'])(.*?)\2", re.I | re.S)
CSS_URL_RE = re.compile(r"url\(\s*([\"']?)([^)\"']+)\1\s*\)", re.I)


def proxy_href(sid, abs_url):
    return "/api/proxy?u=%s&p=%s" % (sid, quote(abs_url, safe=""))


def map_ref(sid, base, raw, hosts):
    v = (raw or "").strip()
    if not v:
        return raw
    low = v.lower()
    if low.startswith(("#", "data:", "javascript:", "mailto:", "tel:", "blob:", "about:")):
        return raw
    if v.startswith("/api/proxy"):
        return raw
    try:
        abs_url = urljoin(base, v)
    except Exception:
        return raw
    p = urlsplit(abs_url)
    if p.scheme not in ("http", "https"):
        return raw
    if p.hostname not in hosts:
        return raw
    return proxy_href(sid, abs_url)


def rewrite_css(css, base, sid, hosts):
    def repl(m):
        q = m.group(1) or ""
        val = m.group(2).strip()
        new = map_ref(sid, base, val, hosts)
        if new == val:
            return m.group(0)
        return "url(%s%s%s)" % (q, new, q)

    return CSS_URL_RE.sub(repl, css)


def rewrite_html(html, base, sid, hosts):
    def repl_attr(m):
        new = map_ref(sid, base, m.group(3), hosts)
        if new == m.group(3):
            return m.group(0)
        return "%s%s%s%s" % (m.group(1), m.group(2), new, m.group(2))

    html = ATTR_RE.sub(repl_attr, html)

    def repl_srcset(m):
        parts = []
        for chunk in m.group(3).split(","):
            chunk = chunk.strip()
            if not chunk:
                continue
            bits = chunk.split()
            bits[0] = map_ref(sid, base, bits[0], hosts)
            parts.append(" ".join(bits))
        return "%s%s%s%s" % (m.group(1), m.group(2), ", ".join(parts), m.group(2))

    html = SRCSET_RE.sub(repl_srcset, html)
    html = rewrite_css(html, base, sid, hosts)
    return html


# ---------------------------------------------------------------------------
# 在线状态
# -------------------------------------------------------------------------
def check_online(url, timeout=1.2):
    try:
        p = urlsplit(url)
        host = p.hostname
        if not host:
            return False
        port = p.port or (443 if p.scheme == "https" else 80)
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except Exception:
        return False


# ---------------------------------------------------------------------------
# HTTP 处理
# ---------------------------------------------------------------------------
class Handler(BaseHTTPRequestHandler):
    server_version = "fnshortcut/" + VERSION
    protocol_version = "HTTP/1.1"

    # --- 基础输出 ---------------------------------------------------------
    def _send(self, body, ctype="application/json; charset=utf-8", code=200, extra=None):
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache")
        self.send_header("X-Content-Type-Options", "nosniff")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _json(self, obj, code=200):
        self._send(json.dumps(obj, ensure_ascii=False), code=code)

    def _error(self, msg, code=400):
        self._json({"ok": False, "error": msg}, code=code)

    def _read_body(self, limit=8 * 1024 * 1024):
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            n = 0
        if n <= 0:
            return b""
        return self.rfile.read(min(n, limit))

    def _read_json(self):
        raw = self._read_body()
        if not raw:
            return {}
        try:
            return json.loads(raw.decode("utf-8"))
        except Exception:
            return None

    def log_message(self, fmt, *args):
        pass

    # --- 静态文件 ---------------------------------------------------------
    def _serve_static(self, path):
        rel = path.lstrip("/") or "index.html"
        if rel == "":
            rel = "index.html"
        full = os.path.normpath(os.path.join(WEB_DIR, rel))
        if not full.startswith(WEB_DIR) or not os.path.isfile(full):
            self._send("Not Found", "text/plain; charset=utf-8", 404)
            return
        ctype, _ = mimetypes.guess_type(full)
        if full.endswith(".js"):
            ctype = "application/javascript; charset=utf-8"
        elif full.endswith(".css"):
            ctype = "text/css; charset=utf-8"
        elif full.endswith(".html"):
            ctype = "text/html; charset=utf-8"
        elif full.endswith(".svg"):
            ctype = "image/svg+xml"
        try:
            with open(full, "rb") as f:
                data = f.read()
        except Exception:
            self._send("Read Error", "text/plain; charset=utf-8", 500)
            return
        cache = "public, max-age=3600" if "/assets/" in rel else "no-cache"
        body = data
        self.send_response(200)
        self.send_header("Content-Type", ctype or "application/octet-stream")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    # --- 路由 -------------------------------------------------------------
    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Content-Length", "0")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        try:
            self._route_get()
        except Exception as exc:  # noqa: BLE001
            self._error("服务器异常: %s" % exc, 500)

    def do_POST(self):
        try:
            self._route_post()
        except Exception as exc:  # noqa: BLE001
            self._error("服务器异常: %s" % exc, 500)

    def do_PUT(self):
        try:
            self._route_put()
        except Exception as exc:  # noqa: BLE001
            self._error("服务器异常: %s" % exc, 500)

    def do_DELETE(self):
        try:
            self._route_delete()
        except Exception as exc:  # noqa: BLE001
            self._error("服务器异常: %s" % exc, 500)

    # GET ------------------------------------------------------------------
    def _route_get(self):
        parts = urlsplit(self.path)
        path = parts.path
        query = parse_qs(parts.query)

        if path == "/api/health":
            self._json({"ok": True, "app": APPNAME, "version": VERSION, "port": PORT})
            return
        if path == "/api/shortcuts":
            store = load_store()
            enabled = query.get("status", ["0"])[0] == "1"
            if enabled:
                items = store["items"]
                results = {}

                def work(it):
                    results[it["id"]] = check_online(it["url"])

                threads = [threading.Thread(target=work, args=(it,)) for it in items]
                for t in threads:
                    t.daemon = True
                    t.start()
                for t in threads:
                    t.join(timeout=2.0)
                store["online"] = results
            self._json({"ok": True, **store})
            return
        if path == "/favicon.ico":
            self._send(b"", "image/x-icon", 204)
            return
        if path.startswith("/api/icon/"):
            sid = path[len("/api/icon/"):]
            self._serve_icon(sid)
            return
        if path == "/api/proxy":
            sid = (query.get("u") or [""])[0]
            target = (query.get("p") or [""])[0]
            self._serve_proxy(sid, target)
            return
        if path.startswith("/api/"):
            self._error("未知接口", 404)
            return
        self._serve_static(path)

    # POST ------------------------------------------------------------------
    def _route_post(self):
        path = urlsplit(self.path).path

        if path == "/api/shortcuts":
            self._create_shortcut()
            return
        if path == "/api/settings":
            body = self._read_json()
            if body is None:
                self._error("请求格式错误")
                return
            store = load_store()
            if isinstance(body, dict):
                for k, v in body.items():
                    if k in store["settings"]:
                        store["settings"][k] = v
            save_store(store)
            self._json({"ok": True, "settings": store["settings"]})
            return
        if path == "/api/favicons":
            body = self._read_json() or {}
            ids = body.get("ids") or []
            items = self._refresh_icons(ids)
            self._json({"ok": True, "items": items})
            return
        if path == "/api/import":
            body = self._read_json()
            if not body or not isinstance(body.get("items"), list):
                self._error("导入内容格式不正确")
                return
            self._import_items(body["items"])
            return

        m = re.match(r"^/api/shortcuts/([a-zA-Z0-9]+)/icon$", path)
        if m:
            self._upload_icon(m.group(1))
            return
        m = re.match(r"^/api/shortcuts/([a-zA-Z0-9]+)/touch$", path)
        if m:
            sid = m.group(1)
            store = load_store()
            for it in store["items"]:
                if it["id"] == sid:
                    it["openCount"] = int(it.get("openCount", 0)) + 1
                    it["lastOpened"] = int(time.time())
                    save_store(store)
                    self._json({"ok": True})
                    return
            self._error("快捷方式不存在", 404)
            return

        self._error("未知接口", 404)

    # PUT -------------------------------------------------------------------
    def _route_put(self):
        path = urlsplit(self.path).path
        m = re.match(r"^/api/shortcuts/([a-zA-Z0-9]+)$", path)
        if not m:
            self._error("未知接口", 404)
            return
        body = self._read_json()
        if body is None:
            self._error("请求格式错误")
            return
        sid = m.group(1)
        store = load_store()
        target = None
        for it in store["items"]:
            if it["id"] == sid:
                target = it
                break
        if not target:
            self._error("快捷方式不存在", 404)
            return

        if "url" in body:
            try:
                target["url"] = normalize_url(body["url"])
            except ValueError as exc:
                self._error(str(exc))
                return
        if "name" in body:
            target["name"] = (body.get("name") or "").strip()[:60] or display_host(target["url"])
        if "note" in body:
            target["note"] = (body.get("note") or "").strip()[:120]
        if "openMode" in body and body["openMode"] in ("iframe", "proxy", "browser"):
            target["openMode"] = body["openMode"]
        if "color" in body:
            target["color"] = body["color"] or pick_color(target["name"])
        if "iconMode" in body and body["iconMode"] in ("auto", "letter"):
            if body["iconMode"] == "letter":
                self._remove_icon(sid)
            target["iconMode"] = body["iconMode"]
        save_store(store)
        self._json({"ok": True, "item": target})

    # DELETE ----------------------------------------------------------------
    def _route_delete(self):
        path = urlsplit(self.path).path
        m = re.match(r"^/api/shortcuts/([a-zA-Z0-9]+)$", path)
        if not m:
            self._error("未知接口", 404)
            return
        sid = m.group(1)
        store = load_store()
        before = len(store["items"])
        store["items"] = [it for it in store["items"] if it["id"] != sid]
        save_store(store)
        self._remove_icon(sid)
        self._json({"ok": True, "removed": before - len(store["items"])})

    # 业务实现 ---------------------------------------------------------
    def _create_shortcut(self):
        body = self._read_json()
        if body is None:
            self._error("请求格式错误")
            return
        try:
            url = normalize_url(body.get("url"))
        except ValueError as exc:
            self._error(str(exc))
            return
        if not url:
            self._error("请填写 IP 或网址")
            return

        name = (body.get("name") or "").strip()[:60] or display_host(url)
        store = load_store()
        item = {
            "id": new_id(),
            "name": name,
            "url": url,
            "note": (body.get("note") or "").strip()[:120],
            "openMode": body.get("openMode") if body.get("openMode") in ("iframe", "proxy", "browser") else "iframe",
            "iconMode": "auto",
            "color": body.get("color") or pick_color(name),
            "createdAt": int(time.time()),
            "openCount": 0,
        }
        store["items"].append(item)
        save_store(store)

        self._refresh_icons([item["id"]], timeout=4.5)
        store = load_store()
        for it in store["items"]:
            if it["id"] == item["id"]:
                item = it
        self._json({"ok": True, "item": item})

    def _refresh_icons(self, ids, timeout=6.0):
        """按 id 抓取图标，返回刷新后的完整列表。"""
        store = load_store()
        targets = [it for it in store["items"] if it["id"] in ids] or store["items"]
        results = {}

        def work(it):
            try:
                got = fetch_favicon(it["url"])
            except Exception:
                got = None
            if got:
                data, ext = got
                self._write_icon(it["id"], data, ext)
                results[it["id"]] = True
            else:
                results[it["id"]] = False

        threads = [threading.Thread(target=work, args=(it,)) for it in targets]
        for t in threads:
            t.daemon = True
            t.start()
        for t in threads:
            t.join(timeout=timeout)
        return load_store()["items"]

    def _import_items(self, items):
        store = load_store()
        existing = {it["url"] for it in store["items"]}
        added = 0
        for raw in items:
            try:
                url = normalize_url(raw.get("url"))
            except Exception:
                continue
            if not url or url in existing:
                continue
            name = (raw.get("name") or "").strip()[:60] or display_host(url)
            store["items"].append({
                "id": new_id(),
                "name": name,
                "url": url,
                "note": (raw.get("note") or "").strip()[:120],
                "openMode": raw.get("openMode") if raw.get("openMode") in ("iframe", "proxy", "browser") else "iframe",
                "iconMode": "auto",
                "color": raw.get("color") or pick_color(name),
                "createdAt": int(time.time()),
                "openCount": 0,
            })
            existing.add(url)
            added += 1
        save_store(store)
        self._refresh_icons([])
        self._json({"ok": True, "added": added})

    # 图标 ---------------------------------------------------------
    def _icon_path(self, sid):
        ensure_dirs()
        for ext in ("png", "jpg", "gif", "svg", "ico", "webp"):
            p = os.path.join(ICON_DIR, "%s.%s" % (sid, ext))
            if os.path.exists(p):
                return p
        return None

    def _write_icon(self, sid, data, ext):
        ensure_dirs()
        self._remove_icon(sid)
        ext = "png" if ext == "x-icon" else ext
        p = os.path.join(ICON_DIR, "%s.%s" % (sid, ext))
        with open(p, "wb") as f:
            f.write(data)
        return p

    def _remove_icon(self, sid):
        p = self._icon_path(sid)
        if p and os.path.exists(p):
            try:
                os.remove(p)
            except OSError:
                pass

    def _serve_icon(self, sid):
        p = self._icon_path(sid)
        if not p:
            self._error("no icon", 404)
            return
        ext = p.rsplit(".", 1)[-1]
        ctype = {
            "png": "image/png", "jpg": "image/jpeg", "gif": "image/gif",
            "svg": "image/svg+xml", "ico": "image/x-icon", "webp": "image/webp",
        }.get(ext, "application/octet-stream")
        with open(p, "rb") as f:
            data = f.read()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "public, max-age=300")
        self.end_headers()
        try:
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _upload_icon(self, sid):
        store = load_store()
        item = next((it for it in store["items"] if it["id"] == sid), None)
        if not item:
            self._error("快捷方式不存在", 404)
            return
        data = self._read_body(limit=4 * 1024 * 1024)
        if not data or len(data) < 32:
            self._error("图标内容为空")
            return
        ctype = self.headers.get("Content-Type", "")
        ext, _ = guess_image(data, ctype)
        if not ext:
            self._error("不支持的图片格式，请使用 PNG / JPG / SVG / ICO")
            return
        self._write_icon(sid, data, ext)
        item["iconMode"] = "custom"
        save_store(store)
        self._json({"ok": True, "item": item})

    # 代理 ---------------------------------------------------------
    def _serve_proxy(self, sid, target):
        if not sid or not target:
            self._send("参数缺失", "text/plain; charset=utf-8", 400)
            return
        store = load_store()
        item = next((it for it in store["items"] if it["id"] == sid), None)
        if not item:
            self._send("快捷方式不存在", "text/plain; charset=utf-8", 404)
            return

        allowed = {host_of(item["url"])}
        p = urlsplit(target)
        if p.scheme not in ("http", "https") or p.hostname not in allowed:
            self._send("仅允许代理本快捷方式对应的站点", "text/plain; charset=utf-8", 403)
            return

        headers = {
            "User-Agent": self.headers.get("User-Agent") or "Mozilla/5.0 fnshortcut",
            "Accept": self.headers.get("Accept") or "*/*",
            "Accept-Language": self.headers.get("Accept-Language") or "zh-CN,zh;q=0.9",
            "Accept-Encoding": "identity",
        }
        cookie = self._cookies.get(sid, {})
        if cookie:
            headers["Cookie"] = "; ".join("%s=%s" % (k, v) for k, v in cookie.items())

        req = Request(target, headers=headers, method=self.command)
        try:
            resp = _OPENER_NR.open(req, timeout=12)
        except HTTPError as exc:
            if exc.code in (301, 302, 303, 307, 308):
                loc = exc.headers.get("Location")
                if loc:
                    new_url = urljoin(target, loc)
                    if urlsplit(new_url).hostname in allowed:
                        self.send_response(302)
                        self.send_header("Location", proxy_href(sid, new_url))
                        self.send_header("Content-Length", "0")
                        self.end_headers()
                        return
                    self._send("目标站点跳转到了当前快捷方式之外的地址：%s" % new_url,
                               "text/plain; charset=utf-8", 403)
                    return
            body = b""
            try:
                body = exc.read()
            except Exception:
                pass
            self._send(
                "<h3>代理请求失败（HTTP %s）</h3><p>%s</p>" % (exc.code, target),
                "text/html; charset=utf-8", 502, )
            return
        except URLError as exc:
            self._send(
                "<h3>无法连接目标站点</h3><p>%s</p><p>%s</p>" % (target, exc.reason),
                "text/html; charset=utf-8", 502,
            )
            return
        except Exception as exc:  # noqa: BLE001
            self._send("<h3>代理异常</h3><p>%s</p>" % exc, "text/html; charset=utf-8", 502)
            return

        self._absorb_cookies(sid, resp.headers)

        ctype = resp.headers.get("Content-Type", "application/octet-stream")
        raw = resp.read(16 * 1024 * 1024)
        final_url = resp.geturl()
        try:
            resp.close()
        except Exception:
            pass

        if "text/html" in ctype.lower():
            text = raw.decode("utf-8", "ignore")
            text = rewrite_html(text, final_url, sid, allowed)
            data = text.encode("utf-8")
            ctype = "text/html; charset=utf-8"
        elif "text/css" in ctype.lower():
            text = raw.decode("utf-8", "ignore")
            data = rewrite_css(text, final_url, sid, allowed).encode("utf-8")
            ctype = "text/css; charset=utf-8"
        else:
            data = raw

        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        try:
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            pass

    _cookies = {}

    def _absorb_cookies(self, sid, headers):
        jar = self._cookies.setdefault(sid, {})
        for raw in headers.get_all("Set-Cookie", []) or []:
            first = raw.split(";")[0]
            if "=" not in first:
                continue
            k, v = first.split("=", 1)
            k = k.strip()
            if k:
                jar[k] = v.strip()


def main():
    ensure_dirs()
    mimetypes.add_type("application/javascript", ".js")
    mimetypes.add_type("image/x-icon", ".ico")
    httpd = ThreadingHTTPServer((BIND_HOST, PORT), Handler)
    httpd.daemon_threads = True
    print("fnshortcut listening on %s:%s" % (BIND_HOST, PORT), flush=True)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
