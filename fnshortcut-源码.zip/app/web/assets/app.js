/* 快捷中心 · 前端逻辑 */
(function () {
    "use strict";

    var $ = function (sel, root) { return (root || document).querySelector(sel); };
    var $$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };

    var SVG = {
        more: '<svg viewBox="0 0 24 24" width="16" height="16"><path d="M6 10a2 2 0 1 1 0 4 2 2 0 0 1 0-4zm6 0a2 2 0 1 1 0 4 2 2 0 0 1 0-4zm6 0a2 2 0 1 1 0 4 2 2 0 0 1 0-4z"/></svg>',
        open: '<svg viewBox="0 0 24 24" width="16" height="16"><path d="M14 4h6v6h-2V7.6l-7.3 7.3-1.4-1.4L16.6 6H14V4zM5 6h5v2H7v9h9v-3h2v5H5V6z"/></svg>',
        edit: '<svg viewBox="0 0 24 24" width="16" height="16"><path d="M4 16.5V20h3.5L18.6 8.9l-3.5-3.5L4 16.5zm16.7-10.9l-2.3-2.3 1.4-1.4a1.6 1.6 0 0 1 2.3 0l0 0a1.6 1.6 0 0 1 0 2.3l-1.4 1.4z"/></svg>',
        copy: '<svg viewBox="0 0 24 24" width="16" height="16"><path d="M9 3h9a2 2 0 0 1 2 2v11h-2V5H9V3zM6 7h9a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2zm0 2v10h9V9H6z"/></svg>',
        del: '<svg viewBox="0 0 24 24" width="16" height="16"><path d="M7 7h10l-1 13H8L7 7zm3-3h4l1 1h3v2H6V5h3l1-1z"/></svg>',
        refresh: '<svg viewBox="0 0 24 24" width="16" height="16"><path d="M12 5a7 7 0 0 1 6.5 4.3l1.7-1.7v5.6h-5.6l2-2A5 5 0 1 0 12 17v2a7 7 0 1 1 0-14z"/></svg>',
        proxy: '<svg viewBox="0 0 24 24" width="16" height="16"><path d="M7 5h10l-3-3 1.4-1.4L20.8 5l-5.4 4.4L14 8l3-3H7v3H5V5zM17 19H7l3 3-1.4 1.4L3.2 19l5.4-4.4L10 16l-3 3h10v-3h2v3z"/></svg>'
    };

    var COLORS = ["#2F7CFF", "#7C5CFF", "#00B3A6", "#FF7A45", "#3DA35D", "#E14C6B", "#F0A020", "#4CA3DD"];

    var state = {
        items: [],
        settings: { layout: "grid", size: "md", showStatus: true, theme: "auto" },
        online: {},
        tabs: [],
        active: null,
        query: "",
        iconV: {},
        loaded: false
    };

    var els = {};

    /* ------------------------------------------------------------ 基础工具 */
    function esc(s) {
        return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
            return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
        });
    }

    function toast(msg, bad) {
        var el = els.toast;
        el.textContent = msg;
        el.className = "toast show" + (bad ? " bad" : "");
        clearTimeout(toast._t);
        toast._t = setTimeout(function () { el.className = "toast"; }, 2600);
    }

    function api(path, opts) {
        opts = opts || {};
        if (opts.body && typeof opts.body !== "string") {
            opts.body = JSON.stringify(opts.body);
            opts.headers = Object.assign({ "Content-Type": "application/json" }, opts.headers || {});
        }
        return fetch(path, opts).then(function (res) {
            return res.json().catch(function () { return {}; }).then(function (data) {
                if (!res.ok || data.ok === false) {
                    throw new Error(data.error || ("请求失败 (" + res.status + ")"));
                }
                return data;
            });
        });
    }

    function hostOf(url) {
        try {
            var p = new URL(url);
            var h = p.host;
            if (p.pathname && p.pathname !== "/") h += p.pathname.replace(/\/$/, "");
            return h;
        } catch (e) {
            return url;
        }
    }

    function initialOf(name) {
        var s = (name || "?").trim();
        var m = s.match(/[\u4e00-\u9fa5A-Za-z0-9]/);
        return (m ? m[0] : "?").toUpperCase();
    }

    function shade(hex, ratio) {
        var h = (hex || "#2F7CFF").replace("#", "");
        if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
        var r = parseInt(h.slice(0, 2), 16), g = parseInt(h.slice(2, 4), 16), b = parseInt(h.slice(4, 6), 16);
        r = Math.max(0, Math.min(255, Math.round(r * ratio)));
        g = Math.max(0, Math.min(255, Math.round(g * ratio)));
        b = Math.max(0, Math.min(255, Math.round(b * ratio)));
        return "rgb(" + r + "," + g + "," + b + ")";
    }

    function normalizeInput(raw) {
        var s = (raw || "").trim();
        if (!s) return "";
        if (s.indexOf("//") === 0) s = "http:" + s;
        if (!/^[a-zA-Z][a-zA-Z0-9+.\-]*:\/\//.test(s)) s = "http://" + s;
        try {
            var u = new URL(s);
            if (u.protocol !== "http:" && u.protocol !== "https:") return "";
            if (!u.hostname) return "";
            return u.href;
        } catch (e) {
            return "";
        }
    }

    function sameUrl(a, b) { return (a || "").replace(/\/$/, "") === (b || "").replace(/\/$/, ""); }

    /* ------------------------------------------------------------ 渲染主界面 */
    function render() {
        var q = state.query.trim().toLowerCase();
        var items = state.items.filter(function (it) {
            if (!q) return true;
            return (it.name + " " + it.url + " " + (it.note || "")).toLowerCase().indexOf(q) >= 0;
        });

        document.documentElement.setAttribute("data-size", state.settings.size || "md");
        els.grid.setAttribute("data-layout", state.settings.layout === "list" ? "list" : "grid");

        els.grid.innerHTML = items.map(function (it, i) { return cardHtml(it, i); }).join("");

        var isEmpty = items.length === 0;
        els.empty.classList.toggle("show", isEmpty);
        els.grid.style.display = isEmpty ? "none" : "";

        if (isEmpty && q) {
            $(".empty h2", els.empty).textContent = "没有匹配的快捷方式";
            $(".empty p", els.empty).innerHTML = "换个关键词试试，或清空搜索框。";
            $("#btnEmptyAdd", els.empty).style.display = "none";
        } else if (isEmpty) {
            $(".empty h2", els.empty).textContent = "还没有快捷方式";
            $(".empty p", els.empty).innerHTML = "输入路由器、下载器、影音服务的 IP 或网址，<br>自动生成图标，点击即可在飞牛窗口内打开。";
            $("#btnEmptyAdd", els.empty).style.display = "";
        }

        els.footLeft.textContent = "共 " + state.items.length + " 个快捷方式" +
            (q ? " · 筛选出 " + items.length + " 个" : "");
        els.btnLayout.classList.toggle("on", state.settings.layout === "list");
        els.btnStatus.classList.toggle("on", !!state.settings.showStatus);
    }

    function cardHtml(it, i) {
        var listMode = state.settings.layout === "list";
        var showDot = state.settings.showStatus && state.online.hasOwnProperty(it.id);
        var online = state.online[it.id];
        var modeBadge = it.openMode === "proxy" ? "兼容" : (it.openMode === "browser" ? "标签页" : "");
        var v = state.iconV[it.id] || it.createdAt || 0;
        var dot = showDot
            ? '<span class="dot ' + (online ? "ok" : "bad") + '" title="' + (online ? "在线" : "无法连接") + '"></span>'
            : "";
        var tile;

        if (it.iconMode === "letter") {
            tile = '<div class="tile is-letter" style="background:linear-gradient(135deg,' + esc(it.color) + ' 0%,' +
                shade(it.color, 0.72) + ' 100%)"><span class="tile-letter">' + esc(initialOf(it.name)) + "</span>" + dot + "</div>";
        } else {
            tile = '<div class="tile" data-letter="' + esc(initialOf(it.name)) + '" data-color="' + esc(it.color) + '">' +
                '<img src="/api/icon/' + esc(it.id) + "?v=" + v + '" alt="" loading="lazy" onerror="fallbackTile(this)">' +
                dot + "</div>";
        }

        return '<article class="card" data-id="' + esc(it.id) + '" data-mode="' + esc(it.openMode) + '"' +
            (listMode ? ' data-list="1"' : "") +
            ' style="--i:' + i + '" tabindex="0" role="button" aria-label="打开 ' + esc(it.name) + '">' +
            (modeBadge ? '<span class="badge-mode">' + modeBadge + "</span>" : "") +
            '<button class="card-more" data-act="menu" title="更多操作">' + SVG.more + "</button>" +
            '<div class="tile-wrap">' + tile + "</div>" +
            '<div class="card-body">' +
            '<div class="card-name">' + esc(it.name) + "</div>" +
            '<div class="card-host">' + esc(hostOf(it.url)) + "</div>" +
            (it.note ? '<div class="card-note">' + esc(it.note) + "</div>" : "") +
            "</div></article>";
    }

    window.fallbackTile = function (img) {
        var tile = img.parentNode;
        if (!tile) return;
        var dot = tile.querySelector(".dot");
        var color = tile.getAttribute("data-color") || "#2F7CFF";
        tile.classList.add("is-letter");
        tile.style.background = "linear-gradient(135deg," + color + " 0%, " + shade(color, 0.72) + " 100%)";
        tile.innerHTML = "";
        var letter = document.createElement("span");
        letter.className = "tile-letter";
        letter.textContent = tile.getAttribute("data-letter") || "?";
        tile.appendChild(letter);
        if (dot) tile.appendChild(dot);
    };

    /* ---------------------------------------------------------------- 数据 */
    function load() {
        var q = state.settings.showStatus ? "?status=1" : "";
        return api("/api/shortcuts" + q).then(function (data) {
            state.items = data.items || [];
            state.settings = Object.assign(state.settings, data.settings || {});
            state.online = data.online || {};
            state.loaded = true;
            applyTheme(state.settings.theme);
            render();
        }).catch(function (err) {
            toast("加载失败：" + err.message, true);
        });
    }

    function itemById(id) {
        for (var i = 0; i < state.items.length; i++) if (state.items[i].id === id) return state.items[i];
        return null;
    }

    /* ---------------------------------------------------------------- 主题 */
    function applyTheme(theme) {
        var mql = window.matchMedia("(prefers-color-scheme: light)");
        var resolved = theme === "light" ? "light" : theme === "dark" ? "dark" : (mql.matches ? "light" : "dark");
        document.documentElement.setAttribute("data-theme", resolved);
    }

    /* -------------------------------------------------------------- 窗口部分 */
    function openItem(item) {
        if (!item) return;
        if (item.openMode === "browser") {
            window.open(item.url, "_blank", "noopener");
            return;
        }
        var exists = state.tabs.some(function (t) { return t.id === item.id; });
        if (!exists) state.tabs.push({ id: item.id });
        state.active = item.id;
        els.windowLayer.classList.remove("hidden");
        renderTabs();
        loadFrame();
        api("/api/shortcuts/" + item.id + "/touch", { method: "POST" }).catch(function () {});
    }

    function renderTabs() {
        els.tabs.innerHTML = state.tabs.map(function (t) {
            var it = itemById(t.id);
            if (!it) return "";
            var active = t.id === state.active;
            var icon = it.iconMode === "letter"
                ? '<span class="tab-icon" style="background:' + esc(it.color) + '">' + esc(initialOf(it.name)) + "</span>"
                : '<span class="tab-icon" style="background:' + esc(it.color) + '"><img src="/api/icon/' + esc(it.id) + '?v=' + (state.iconV[it.id] || it.createdAt || 0) + '" alt=""></span>';
            return '<div class="tab' + (active ? " active" : "") + '" data-tab="' + esc(it.id) + '" role="tab">' +
                icon + '<span class="tab-label">' + esc(it.name) + "</span>" +
                '<span class="tab-close" data-close="' + esc(it.id) + '" title="关闭">' +
                '<svg viewBox="0 0 24 24" width="12" height="12"><path d="M6.4 5l5.6 5.6L17.6 5 19 6.4 13.4 12 19 17.6 17.6 19 12 13.4 6.4 19 5 17.6 10.6 12 5 6.4z"/></svg>' +
                "</span></div>";
        }).join("");
    }

    function frameSrc(it) {
        if (it.openMode === "proxy") {
            return "/api/proxy?u=" + encodeURIComponent(it.id) + "&p=" + encodeURIComponent(it.url);
        }
        return it.url;
    }

    function loadFrame() {
        var it = itemById(state.active);
        if (!it) { closeWindow(); return; }
        els.winUrl.textContent = it.url;
        els.winModeChip.textContent = it.openMode === "proxy" ? "兼容模式" : "直连";
        els.winModeChip.className = "mode-chip" + (it.openMode === "proxy" ? " proxy" : "");
        els.winFrame.src = frameSrc(it);
    }

    function closeTab(id) {
        state.tabs = state.tabs.filter(function (t) { return t.id !== id; });
        if (state.active === id) {
            state.active = state.tabs.length ? state.tabs[state.tabs.length - 1].id : null;
        }
        if (!state.tabs.length) { closeWindow(); return; }
        renderTabs();
        loadFrame();
    }

    function closeWindow() {
        state.tabs = [];
        state.active = null;
        els.windowLayer.classList.add("hidden");
        els.winFrame.src = "about:blank";
    }

    /* -------------------------------------------------------------- 添加/编辑 */
    var modal = { item: null, mode: "iframe", iconChoice: "auto", color: "#2F7CFF", file: null };

    function openEditor(item) {
        modal.item = item || null;
        modal.mode = item ? item.openMode : "iframe";
        modal.iconChoice = item ? (item.iconMode === "letter" ? "letter" : "auto") : "auto";
        modal.color = item ? item.color : "#2F7CFF";
        modal.file = null;

        var editing = !!item;
        var v = item ? (state.iconV[item.id] || item.createdAt || 0) : 0;

        els.modalBox.innerHTML =
            '<div class="modal-head">' +
            '<div><h3 class="modal-title">' + (editing ? "编辑快捷方式" : "新建快捷方式") + "</h3>" +
            '<p class="modal-sub">' + (editing ? "修改名称、地址或打开方式" : "输入 IP 或网址，自动生成图标") + "</p></div>" +
            '<button class="icon-btn sm modal-close" data-close-modal title="关闭"><svg viewBox="0 0 24 24" width="16" height="16"><path d="M6.4 5l5.6 5.6L17.6 5 19 6.4 13.4 12 19 17.6 17.6 19 12 13.4 6.4 19 5 17.6 10.6 12 5 6.4z"/></svg></button>' +
            "</div>" +
            '<div class="modal-body">' +
            '<div class="field"><label>名称</label>' +
            '<input class="input" id="fName" maxlength="60" placeholder="例如：路由器 / 下载器 / 影音库" value="' + esc(item ? item.name : "") + '">' +
            "</div>" +
            '<div class="field"><label>地址 <span class="req">*</span></label>' +
            '<input class="input" id="fUrl" spellcheck="false" autocomplete="off" placeholder="192.168.1.1 或 https://example.com:8080" value="' + esc(item ? item.url : "") + '">' +
            '<div class="help" id="fUrlHelp">支持 IP、域名、带端口或路径的地址，未写协议时默认使用 http://</div>' +
            "</div>" +
            '<div class="field"><label>打开方式</label><div class="modes" id="fModes">' +
            modeBtn("iframe", "内嵌窗口", "飞牛窗口内直接打开") +
            modeBtn("proxy", "兼容模式", "站点禁止嵌入时使用") +
            modeBtn("browser", "浏览器标签", "新标签页打开") +
            "</div></div>" +
            '<div class="field"><label>图标</label><div class="icon-row">' +
            '<div class="preview-tile" id="fPreview"></div>' +
            '<div class="icon-actions">' +
            '<button class="ghost-btn" id="fFetch">自动抓取图标</button>' +
            '<button class="ghost-btn" id="fUpload">上传图片</button>' +
            '<button class="ghost-btn" id="fLetter">使用文字图标</button>' +
            '<input type="file" id="fFile" accept="image/png,image/jpeg,image/svg+xml,image/x-icon,image/webp" hidden>' +
            "</div></div>" +
            '<div class="swatches">' +
            COLORS.map(function (c) {
                return '<button class="swatch' + (c === modal.color ? " active" : "") + '" data-color="' + c +
                    '" style="background:' + c + '" title="' + c + '"></button>';
            }).join("") +
            "</div>" +
            '<div class="help">抓取失败时会自动使用名称首字生成图标，色块用于文字图标底色</div>' +
            "</div>" +
            '<div class="field"><label>备注（可选）</label>' +
            '<input class="input" id="fNote" maxlength="120" placeholder="例如：客厅电视旁边的下载机" value="' + esc(item ? (item.note || "") : "") + '">' +
            "</div>" +
            "</div>" +
            '<div class="modal-foot">' +
            (editing ? '<button class="danger-btn" id="fDelete">删除</button>' : "") +
            '<button class="ghost-btn" data-close-modal>取消</button>' +
            '<button class="primary-btn" id="fSave">' + (editing ? "保存修改" : "创建快捷方式") + "</button>" +
            "</div>";

        els.modalLayer.classList.remove("hidden");
        renderPreview(v);
        syncModes();

        var nameEl = $("#fName", els.modalBox);
        var urlEl = $("#fUrl", els.modalBox);
        $("#fUrl", els.modalBox).focus();

        nameEl.addEventListener("input", function () { renderPreview(v); });
        urlEl.addEventListener("input", function () {
            urlEl.classList.remove("err");
            var help = $("#fUrlHelp", els.modalBox);
            help.classList.remove("err");
            help.textContent = "支持 IP、域名、带端口或路径的地址，未写协议时默认使用 http://";
            renderPreview(v);
        });
        urlEl.addEventListener("keydown", function (e) {
            if (e.key === "Enter") { e.preventDefault(); saveEditor(); }
        });

        $("#fModes", els.modalBox).addEventListener("click", function (e) {
            var btn = e.target.closest(".mode");
            if (!btn) return;
            modal.mode = btn.getAttribute("data-mode");
            syncModes();
        });

        $("#fFetch", els.modalBox).addEventListener("click", function () {
            if (!modal.item) {
                modal.iconChoice = "auto";
                modal.file = null;
                toast("创建后会自动抓取站点图标");
                renderPreview(v);
                return;
            }
            this.disabled = true;
            var self = this;
            api("/api/favicons", { method: "POST", body: { ids: [modal.item.id] } }).then(function (data) {
                var fresh = (data.items || []).filter(function (x) { return x.id === modal.item.id; })[0];
                if (fresh) {
                    modal.item = fresh;
                    modal.iconChoice = "auto";
                    state.iconV[fresh.id] = Date.now();
                    state.items = state.items.map(function (x) { return x.id === fresh.id ? fresh : x; });
                    render();
                    renderPreview(state.iconV[fresh.id]);
                    toast("图标已更新");
                }
            }).catch(function (err) {
                toast("抓取失败：" + err.message, true);
            }).then(function () {
                self.disabled = false;
            });
        });

        $("#fUpload", els.modalBox).addEventListener("click", function () { $("#fFile", els.modalBox).click(); });
        $("#fFile", els.modalBox).addEventListener("change", function () {
            var file = this.files && this.files[0];
            if (!file) return;
            if (file.size > 4 * 1024 * 1024) { toast("图片不要超过 4 MB", true); return; }
            modal.file = file;
            modal.iconChoice = "custom";
            var reader = new FileReader();
            reader.onload = function () { renderPreview(0, reader.result); };
            reader.readAsDataURL(file);
        });

        $("#fLetter", els.modalBox).addEventListener("click", function () {
            modal.iconChoice = "letter";
            modal.file = null;
            renderPreview(v);
        });

        $$(".swatch", els.modalBox).forEach(function (s) {
            s.addEventListener("click", function () {
                modal.color = s.getAttribute("data-color");
                $$(".swatch", els.modalBox).forEach(function (x) { x.classList.remove("active"); });
                s.classList.add("active");
                renderPreview(v);
            });
        });

        $("#fSave", els.modalBox).addEventListener("click", saveEditor);
        if (editing) {
            $("#fDelete", els.modalBox).addEventListener("click", function () {
                confirmDialog("删除「" + item.name + "」？", "删除后不可恢复，站点本身不受影响。", function () {
                    api("/api/shortcuts/" + item.id, { method: "DELETE" }).then(function () {
                        closeModal();
                        state.tabs = state.tabs.filter(function (t) { return t.id !== item.id; });
                        if (!state.tabs.length) closeWindow(); else { renderTabs(); loadFrame(); }
                        load();
                        toast("已删除");
                    }).catch(function (err) { toast(err.message, true); });
                });
            });
        }
    }

    function modeBtn(mode, name, desc) {
        return '<button class="mode" data-mode="' + mode + '"><span class="mode-name">' + name +
            '</span><span class="mode-desc">' + desc + "</span></button>";
    }

    function syncModes() {
        $$(".mode", els.modalBox).forEach(function (b) {
            b.classList.toggle("active", b.getAttribute("data-mode") === modal.mode);
        });
    }

    function renderPreview(v, dataUrl) {
        var box = $("#fPreview", els.modalBox);
        if (!box) return;
        var name = ($("#fName", els.modalBox) || {}).value || "";
        var urlRaw = ($("#fUrl", els.modalBox) || {}).value || "";
        var label = name || hostOf(urlRaw) || "?";
        var shown = dataUrl;

        if (!shown && modal.iconChoice === "auto" && modal.item && modal.item.iconMode !== "letter") {
            shown = "/api/icon/" + modal.item.id + "?v=" + (v || 0);
        }

        if (shown) {
            box.style.background = "rgba(255,255,255,.06)";
            box.innerHTML = '<img src="' + esc(shown) + '" alt="" onerror="previewLetter(this)">';
        } else {
            box.style.background = "linear-gradient(135deg," + modal.color + " 0%, " + shade(modal.color, 0.72) + " 100%)";
            box.innerHTML = "<span>" + esc(initialOf(label)) + "</span>";
        }
    }

    window.previewLetter = function (img) {
        var box = img.parentNode;
        var name = ($("#fName", document) || {}).value || "";
        var urlRaw = ($("#fUrl", document) || {}).value || "";
        var label = name || hostOf(urlRaw) || "?";
        box.style.background = "linear-gradient(135deg," + modal.color + " 0%, " + shade(modal.color, 0.72) + " 100%)";
        box.innerHTML = "<span>" + esc(initialOf(label)) + "</span>";
    };

    function saveEditor() {
        var name = ($("#fName", els.modalBox).value || "").trim();
        var raw = ($("#fUrl", els.modalBox).value || "").trim();
        var note = ($("#fNote", els.modalBox).value || "").trim();
        var url = normalizeInput(raw);

        if (!url) {
            var el = $("#fUrl", els.modalBox);
            el.classList.add("err");
            var help = $("#fUrlHelp", els.modalBox);
            help.classList.add("err");
            help.textContent = "地址格式不正确，请输入 IP、域名或完整网址";
            el.focus();
            return;
        }

        var payload = { name: name, url: url, note: note, openMode: modal.mode, color: modal.color };
        if (modal.iconChoice === "letter") payload.iconMode = "letter";
        else if (modal.iconChoice === "auto") payload.iconMode = "auto";

        var btn = $("#fSave", els.modalBox);
        var editing = !!modal.item;
        btn.disabled = true;

        var req = modal.item
            ? api("/api/shortcuts/" + modal.item.id, { method: "PUT", body: payload })
            : api("/api/shortcuts", { method: "POST", body: payload });

        req.then(function (data) {
            var item = data.item;
            var upload = null;
            if (modal.file) {
                upload = fetch("/api/shortcuts/" + item.id + "/icon", {
                    method: "POST",
                    headers: { "Content-Type": modal.file.type || "image/png" },
                    body: modal.file
                }).then(function (res) { return res.json(); }).catch(function () { return null; });
            }
            return Promise.resolve(upload).then(function () {
                state.iconV[item.id] = Date.now();
                closeModal();
                return load().then(function () {
                    toast(editing ? "已保存" : "快捷方式已创建");
                });
            });
        }).catch(function (err) {
            btn.disabled = false;
            toast(err.message, true);
        });
    }

    function closeModal() {
        els.modalLayer.classList.add("hidden");
        els.modalBox.innerHTML = "";
        modal.item = null;
    }

    function confirmDialog(title, desc, onOk) {
        els.modalBox.innerHTML =
            '<div class="modal-head"><div><h3 class="modal-title">' + esc(title) + "</h3>" +
            '<p class="modal-sub">' + esc(desc) + "</p></div></div>" +
            '<div class="modal-foot"><button class="ghost-btn" data-close-modal>取消</button>' +
            '<button class="primary-btn" id="cOk" style="background:linear-gradient(135deg,#ff7a72,#e5484d);box-shadow:0 6px 18px rgba(229,72,77,.3)">确认删除</button></div>';
        els.modalLayer.classList.remove("hidden");
        $("#cOk", els.modalBox).addEventListener("click", function () {
            closeModal();
            onOk();
        });
    }

    /* --------------------------------------------------------------- 更多菜单 */
    function openMenu(item, anchor) {
        var html = "";
        html += itemBtn("open", SVG.open, item.openMode === "browser" ? "在新标签页打开" : "在窗口内打开");
        html += itemBtn("browser", SVG.open, "在浏览器打开");
        html += itemBtn("edit", SVG.edit, "编辑");
        html += itemBtn("icon", SVG.refresh, "重新抓取图标");
        html += itemBtn("proxy", SVG.proxy, item.openMode === "proxy" ? "改为直连模式" : "改为兼容模式");
        html += itemBtn("copy", SVG.copy, "复制地址");
        html += '<div class="menu-sep"></div>';
        html += itemBtn("delete", SVG.del, "删除", true);

        els.menu.innerHTML = html;
        els.menu.classList.remove("hidden");
        els.menu.setAttribute("data-id", item.id);

        var r = anchor.getBoundingClientRect();
        var w = els.menu.offsetWidth, h = els.menu.offsetHeight;
        var left = Math.min(r.right - w, window.innerWidth - w - 10);
        var top = r.bottom + 6;
        if (top + h > window.innerHeight - 10) top = Math.max(10, r.top - h - 6);
        els.menu.style.left = Math.max(10, left) + "px";
        els.menu.style.top = top + "px";
    }

    function itemBtn(act, icon, label, danger) {
        return '<button class="menu-item' + (danger ? " danger" : "") + '" data-act="' + act + '">' + icon + "<span>" + label + "</span></button>";
    }

    function closeMenu() { els.menu.classList.add("hidden"); }

    /* ---------------------------------------------------------------- 设置 */
    function openSettings() {
        var s = state.settings;
        els.modalBox.innerHTML =
            '<div class="modal-head"><div><h3 class="modal-title">设置</h3>' +
            '<p class="modal-sub">界面偏好与数据管理</p></div>' +
            '<button class="icon-btn sm modal-close" data-close-modal><svg viewBox="0 0 24 24" width="16" height="16"><path d="M6.4 5l5.6 5.6L17.6 5 19 6.4 13.4 12 19 17.6 17.6 19 12 13.4 6.4 19 5 17.6 10.6 12 5 6.4z"/></svg></button></div>' +
            '<div class="modal-body">' +
            '<div class="setting-row"><div><div class="st-name">在线状态检测</div>' +
            '<div class="st-desc">打开页面时探测各站点端口，显示绿点/红点</div></div>' +
            '<div class="st-ctrl"><div class="switch' + (s.showStatus ? " on" : "") + '" data-switch="showStatus"></div></div></div>' +
            '<div class="setting-row"><div><div class="st-name">卡片尺寸</div>' +
            '<div class="st-desc">影响网格每列的最小宽度</div></div>' +
            '<div class="st-ctrl"><div class="seg" data-seg="size">' +
            segBtn("sm", "紧凑", s.size) + segBtn("md", "标准", s.size) + segBtn("lg", "大", s.size) +
            "</div></div></div>" +
            '<div class="setting-row"><div><div class="st-name">布局方式</div>' +
            '<div class="st-desc">磁贴网格或列表</div></div>' +
            '<div class="st-ctrl"><div class="seg" data-seg="layout">' +
            segBtn("grid", "网格", s.layout) + segBtn("list", "列表", s.layout) +
            "</div></div></div>" +
            '<div class="setting-row"><div><div class="st-name">主题</div>' +
            '<div class="st-desc">跟随飞牛桌面深浅色或手动指定</div></div>' +
            '<div class="st-ctrl"><div class="seg" data-seg="theme">' +
            segBtn("auto", "跟随", s.theme) + segBtn("light", "浅色", s.theme) + segBtn("dark", "深色", s.theme) +
            "</div></div></div>" +
            '<div class="setting-row"><div><div class="st-name">数据管理</div>' +
            '<div class="st-desc">导出为 JSON 备份，或从备份文件导入</div></div>' +
            '<div class="st-ctrl" style="display:flex;gap:8px">' +
            '<button class="ghost-btn" id="sExport">导出</button>' +
            '<button class="ghost-btn" id="sImport">导入</button>' +
            '<input type="file" id="sFile" accept="application/json,.json" hidden>' +
            "</div></div>" +
            '<div class="setting-row"><div><div class="st-name">关于</div>' +
            '<div class="st-desc">快捷中心 v1.0.0 · 服务端口 8899 · 数据保存在应用的 var 目录，卸载保留<br>' +
            "兼容模式由 NAS 侧反向代理目标站点，适合内部管理页；带登录态的复杂站点建议用浏览器打开</div></div></div>" +
            "</div>" +
            '<div class="modal-foot"><button class="ghost-btn" data-close-modal>关闭</button></div>';

        els.modalLayer.classList.remove("hidden");

        $$("[data-switch]", els.modalBox).forEach(function (sw) {
            sw.addEventListener("click", function () {
                var key = sw.getAttribute("data-switch");
                s[key] = !s[key];
                sw.classList.toggle("on", s[key]);
                saveSettings({ showStatus: s[key] }).then(load);
            });
        });

        $$("[data-seg]", els.modalBox).forEach(function (seg) {
            seg.addEventListener("click", function (e) {
                var btn = e.target.closest("button");
                if (!btn) return;
                var key = seg.getAttribute("data-seg");
                var val = btn.getAttribute("data-val");
                $$("button", seg).forEach(function (b) { b.classList.remove("active"); });
                btn.classList.add("active");
                s[key] = val;
                if (key === "theme") applyTheme(val);
                saveSettings({ [key]: val });
                render();
            });
        });

        $("#sExport", els.modalBox).addEventListener("click", exportData);
        $("#sImport", els.modalBox).addEventListener("click", function () { $("#sFile", els.modalBox).click(); });
        $("#sFile", els.modalBox).addEventListener("change", function () {
            var file = this.files && this.files[0];
            if (!file) return;
            var reader = new FileReader();
            reader.onload = function () {
                try {
                    var data = JSON.parse(reader.result);
                    var items = Array.isArray(data) ? data : (data.items || []);
                    if (!items.length) throw new Error("文件里没有可导入的快捷方式");
                    api("/api/import", { method: "POST", body: { items: items } }).then(function (res) {
                        closeModal();
                        load();
                        toast("已导入 " + res.added + " 个快捷方式");
                    });
                } catch (err) {
                    toast("导入失败：" + err.message, true);
                }
            };
            reader.readAsText(file);
        });
    }

    function segBtn(val, label, current) {
        return '<button data-val="' + val + '" class="' + (current === val ? "active" : "") + '">' + label + "</button>";
    }

    function saveSettings(patch) {
        return api("/api/settings", { method: "POST", body: patch }).catch(function () {});
    }

    function exportData() {
        var data = {
            app: "fnshortcut",
            version: "1.0.0",
            exportedAt: new Date().toISOString(),
            items: state.items.map(function (it) {
                return { name: it.name, url: it.url, note: it.note, openMode: it.openMode, color: it.color };
            })
        };
        var blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
        var a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = "fnshortcut-" + new Date().toISOString().slice(0, 10) + ".json";
        a.click();
        setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
        toast("已导出备份文件");
    }

    /* ---------------------------------------------------------------- 事件 */
    function bind() {
        els.grid.addEventListener("click", function (e) {
            var card = e.target.closest(".card");
            if (!card) return;
            var item = itemById(card.getAttribute("data-id"));
            if (!item) return;
            if (e.target.closest('[data-act="menu"]')) {
                e.stopPropagation();
                openMenu(item, e.target.closest('[data-act="menu"]'));
                return;
            }
            openItem(item);
        });

        els.grid.addEventListener("keydown", function (e) {
            if (e.key !== "Enter" && e.key !== " ") return;
            var card = e.target.closest(".card");
            if (!card) return;
            e.preventDefault();
            var item = itemById(card.getAttribute("data-id"));
            if (item) openItem(item);
        });

        els.menu.addEventListener("click", function (e) {
            var btn = e.target.closest(".menu-item");
            if (!btn) return;
            var item = itemById(els.menu.getAttribute("data-id"));
            var act = btn.getAttribute("data-act");
            closeMenu();
            if (!item) return;

            if (act === "open") openItem(item);
            else if (act === "browser") window.open(item.url, "_blank", "noopener");
            else if (act === "edit") openEditor(item);
            else if (act === "icon") {
                api("/api/favicons", { method: "POST", body: { ids: [item.id] } }).then(function (data) {
                    var fresh = (data.items || []).filter(function (x) { return x.id === item.id; })[0];
                    if (fresh) {
                        state.iconV[item.id] = Date.now();
                        state.items = state.items.map(function (x) { return x.id === fresh.id ? fresh : x; });
                        render();
                        toast("图标已更新");
                    }
                }).catch(function (err) { toast(err.message, true); });
            } else if (act === "proxy") {
                var next = item.openMode === "proxy" ? "iframe" : "proxy";
                api("/api/shortcuts/" + item.id, { method: "PUT", body: { openMode: next } }).then(function () {
                    item.openMode = next;
                    render();
                    if (state.tabs.some(function (t) { return t.id === item.id; })) {
                        if (state.active === item.id) loadFrame();
                    }
                    toast(next === "proxy" ? "已切换为兼容模式" : "已切换为直连模式");
                }).catch(function (err) { toast(err.message, true); });
            } else if (act === "copy") {
                copyText(item.url);
            } else if (act === "delete") {
                confirmDialog("删除「" + item.name + "」？", "删除后不可恢复，站点本身不受影响。", function () {
                    api("/api/shortcuts/" + item.id, { method: "DELETE" }).then(function () {
                        state.tabs = state.tabs.filter(function (t) { return t.id !== item.id; });
                        if (state.tabs.length) { renderTabs(); loadFrame(); } else { closeWindow(); }
                        load();
                        toast("已删除");
                    }).catch(function (err) { toast(err.message, true); });
                });
            }
        });

        document.addEventListener("click", function (e) {
            if (!e.target.closest("#cardMenu") && !e.target.closest('[data-act="menu"]')) closeMenu();
            if (e.target.closest("[data-close-modal]")) closeModal();
        });

        els.modalLayer.addEventListener("click", function (e) {
            if (e.target === els.modalLayer) closeModal();
        });

        els.btnAdd.addEventListener("click", function () { openEditor(null); });
        $("#btnEmptyAdd", els.empty).addEventListener("click", function () { openEditor(null); });
        els.btnSettings.addEventListener("click", openSettings);

        els.btnLayout.addEventListener("click", function () {
            state.settings.layout = state.settings.layout === "list" ? "grid" : "list";
            saveSettings({ layout: state.settings.layout });
            render();
        });

        els.btnStatus.addEventListener("click", function () {
            state.settings.showStatus = !state.settings.showStatus;
            saveSettings({ showStatus: state.settings.showStatus });
            load();
        });

        var timer = null;
        els.search.addEventListener("input", function () {
            clearTimeout(timer);
            timer = setTimeout(function () {
                state.query = els.search.value || "";
                render();
            }, 120);
        });

        els.tabs.addEventListener("click", function (e) {
            var closeBtn = e.target.closest("[data-close]");
            if (closeBtn) {
                e.stopPropagation();
                closeTab(closeBtn.getAttribute("data-close"));
                return;
            }
            var tab = e.target.closest("[data-tab]");
            if (!tab) return;
            state.active = tab.getAttribute("data-tab");
            renderTabs();
            loadFrame();
        });

        els.winClose.addEventListener("click", closeWindow);

        els.winReload.addEventListener("click", function () {
            var src = els.winFrame.src;
            els.winFrame.src = "about:blank";
            setTimeout(function () { els.winFrame.src = src; }, 60);
        });

        els.winExternal.addEventListener("click", function () {
            var it = itemById(state.active);
            if (it) window.open(it.url, "_blank", "noopener");
        });

        els.winMode.addEventListener("click", function () {
            var it = itemById(state.active);
            if (!it) return;
            var next = it.openMode === "proxy" ? "iframe" : "proxy";
            api("/api/shortcuts/" + it.id, { method: "PUT", body: { openMode: next } }).then(function () {
                it.openMode = next;
                render();
                loadFrame();
                toast(next === "proxy" ? "已切换为兼容模式" : "已切换为直连模式");
            }).catch(function (err) { toast(err.message, true); });
        });

        document.addEventListener("keydown", function (e) {
            if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
                e.preventDefault();
                els.search.focus();
                return;
            }
            if (e.key === "Escape") {
                if (!els.modalLayer.classList.contains("hidden")) { closeModal(); return; }
                if (!els.menu.classList.contains("hidden")) { closeMenu(); return; }
                if (!els.windowLayer.classList.contains("hidden")) { closeWindow(); }
            }
        });

        window.matchMedia("(prefers-color-scheme: light)").addEventListener("change", function () {
            if (state.settings.theme === "auto") applyTheme("auto");
        });
    }

    function copyText(text) {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(function () { toast("地址已复制"); }).catch(function () { fallbackCopy(text); });
        } else {
            fallbackCopy(text);
        }
    }

    function fallbackCopy(text) {
        var ta = document.createElement("textarea");
        ta.value = text;
        ta.style.position = "fixed";
        ta.style.opacity = "0";
        document.body.appendChild(ta);
        ta.select();
        try { document.execCommand("copy"); toast("地址已复制"); } catch (e) { toast("复制失败，请手动选择", true); }
        document.body.removeChild(ta);
    }

    /* ---------------------------------------------------------------- 启动 */
    function init() {
        els = {
            grid: $("#grid"),
            empty: $("#empty"),
            search: $("#search"),
            btnAdd: $("#btnAdd"),
            btnLayout: $("#btnLayout"),
            btnStatus: $("#btnStatus"),
            btnSettings: $("#btnSettings"),
            footLeft: $("#footLeft"),
            footRight: $("#footRight"),
            windowLayer: $("#windowLayer"),
            winFrame: $("#winFrame"),
            winTabs: $("#winTabs"),
            tabs: $("#winTabs"),
            winClose: $("#winClose"),
            winReload: $("#winReload"),
            winExternal: $("#winExternal"),
            winMode: $("#winMode"),
            winModeChip: $("#winModeChip"),
            winUrl: $("#winUrl"),
            modalLayer: $("#modalLayer"),
            modalBox: $("#modalBox"),
            menu: $("#cardMenu"),
            toast: $("#toast")
        };

        applyTheme("auto");
        bind();
        load();
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", init);
    } else {
        init();
    }
})();
